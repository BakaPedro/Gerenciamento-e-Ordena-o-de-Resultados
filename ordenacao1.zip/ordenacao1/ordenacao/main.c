#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct t{
	int min, hora;
}tm;
typedef struct c{
	char nome[30], id[10], data[12];
	tm tempo, tempo2;
	tm dif;
	int total;
}Cor;
int calc(int t1, int t2, int t3, int t4){
	int d, a, b, c;

	t1 = t1 * 60;
	t3 = t3 * 60;
	a = t1 + t2;
	b = t3 + t4;
	c = b - a;
	d = c/60;
	return d;
}
int calc1(int t1, int t2, int t3, int t4){
	int d, a, b, c;

	t1 = t1 * 60;
	t3 = t3 * 60;
	a = t1 + t2;
	b = t3 + t4;
	c = b - a;
	d = c%60;
	return d;
}
int ca(int a, int b){

	int s, t1;
	t1 = a * 60;
	s = t1 + b;
	return s;
}
int abrir(Cor *p, char *entrada){
	FILE *arq = fopen(entrada, "r");
	int i;
	if(arq){
		for (int i = 0; i < 10; ++i){
		fscanf(arq, "%s", p[i].id);
        fscanf(arq, " %[^\n]", p[i].nome);
        fscanf(arq, "%s", p[i].data);
        fscanf(arq, "%d %d", &p[i].tempo.hora, &p[i].tempo.min);
        fscanf(arq, "%d %d", &p[i].tempo2.hora, &p[i].tempo2.min);
        p[i].dif.hora = calc(p[i].tempo.hora, p[i].tempo.min, p[i].tempo2.hora, p[i].tempo2.min);
		p[i].dif.min = calc1(p[i].tempo.hora, p[i].tempo.min, p[i].tempo2.hora, p[i].tempo2.min);
		p[i].total = ca(p[i].dif.hora, p[i].dif.min);
		}
	}
	else{
		printf("deu ruim");
		return -1;
	}
	fclose(arq);
	return 0;
}
int teste(char *entrada){
	FILE *arq = fopen(entrada, "r");
	int i;
	Cor p;
	if(arq){
		while (	fscanf(arq, "%s", p.id) == 1) {
			fscanf(arq, " %[^\n]", p.nome);
			fscanf(arq, "%s", p.data);
			fscanf(arq, "%d %d", &p.tempo.hora, &p.tempo.min);
			fscanf(arq, "%d %d", &p.tempo2.hora, &p.tempo2.min);
			i++;
	}}
	else{
		printf("deu ruim");
		return -1;
	}
	fclose(arq);
	return i;
}
void empurra(Cor *v,int n,int m){
  int aux,i, tempo1, tempo11, tempo2, tempo22, diff, diff2;
  char nome[30], id[10], data1[12];
  aux=v[m].total;
  strcpy(data1, v[m].data);
  strcpy(nome, v[m].nome);
  strcpy(id, v[m].id);
  diff = v[m].dif.hora;
  diff2 = v[m].dif.min;
  tempo1 = v[m].tempo.hora;
  tempo11 = v[m].tempo.min;
  tempo2 = v[m].tempo2.hora;
  tempo22 = v[m].tempo2.min;

  for (i = m; i >n ; --i){
    v[i].total=v[i-1].total;
    v[i].tempo.hora = v[i-1].tempo.hora;
    v[i].tempo.min = v[i-1].tempo.min;
    v[i].tempo2.hora = v[i-1].tempo2.hora;
    v[i].tempo2.min = v[i-1].tempo2.min;
    v[i].dif.hora = v[i-1].dif.hora;
    v[i].dif.min = v[i-1].dif.min;
    strcpy(v[i].data, v[i-1].data);
    strcpy(v[i].nome, v[i-1].nome);
    strcpy(v[i].id, v[i-1].id);
  }
  strcpy(v[n].data, data1);
  strcpy(v[n].nome, nome);
  strcpy(v[n].id, id);
  v[n].tempo.hora = tempo1;
  v[n].tempo.min = tempo11;
  v[n].tempo2.hora = tempo2;
  v[n].tempo2.min = tempo22;
  v[n].dif.hora = diff;
  v[n].dif.min = diff2;
  v[n].total=aux;
}
void insert(Cor *v,int n){
 int i,j;
 for (i = 1; i < n; ++i)
 {
  for (j = i-1; j >=0; --j)
  {
    if(v[i].total>v[j].total){
      break;
    }
  }
  empurra(v,j+1,i);
 }
}

void troca(Cor *v,int i,int j){
  int aux, tempo1, tempo11, tempo2, tempo22, diff, diff2;
  char nome[30], id[10], data1[12];
  aux=v[i].total;
  tempo1 = v[i].tempo.hora;
  tempo11 = v[i].tempo.min;
  tempo2 = v[i].tempo2.hora;
  tempo22 = v[i].tempo2.min;
  strcpy(data1, v[i].data);
  strcpy(nome, v[i].nome);
  strcpy(id, v[i].id);
  diff = v[i].dif.hora;
  diff2 = v[i].dif.min;

  	v[i].total=v[j].total;
    v[i].total=v[j].total;
    v[i].tempo.hora = v[j].tempo.hora;
    v[i].tempo.min = v[j].tempo.min;
    v[i].tempo2.hora = v[j].tempo2.hora;
    v[i].tempo2.min = v[j].tempo2.min;
    v[i].dif.hora = v[j].dif.hora;
    v[i].dif.min = v[j].dif.min;
    strcpy(v[i].data, v[j].data);
    strcpy(v[i].nome, v[j].nome);
    strcpy(v[i].id, v[j].id);

  strcpy(v[j].data, data1);
  strcpy(v[j].nome, nome);
  strcpy(v[j].id, id);
  v[j].tempo.hora = tempo1;
  v[j].tempo.min = tempo11;
  v[j].tempo2.hora = tempo2;
  v[j].tempo2.min = tempo22;
  v[j].dif.hora = diff;
  v[j].dif.min = diff2;
  v[j].total = aux;
}

void selection(Cor *v,int n){
  int i,menor,j;
  for (i = 0; i < n-1; i++) {
    menor=i;
    for (j = i+1; j < n; j++) {
      if(v[menor].total>v[j].total){
        menor=j;
      }
    }
    troca(v,i,menor);
  }
}
void  imprimir(Cor *v,int n){
  int i;
  	printf("======RANK======\n");
  for (i = 0; i < n; i++) {
  	printf("======posicao - %d======\n", i+1);
  	printf("Difenca em horas:%d:%d\n", v[i].dif.hora, v[i].dif.min);
    printf("Difenca em min:%d\n",v[i].total);
    printf("Id:%s\n", v[i].id);
    printf("Data de nascimento:%s\n", v[i].data);
    printf("Nome:%s\n", v[i].nome);
    printf("Hora de saida - %d:%d\n", v[i].tempo.hora, v[i].tempo.min);
    printf("Hora de chegada - %d:%d\n", v[i].tempo2.hora, v[i].tempo2.min);
  }
  printf("\n");
}
int main(int argc, char const *argv[]){
	int c = teste((char *)argv[1]);
	Cor rank[c];
	char s[]="select", i[]="insert";
	abrir(rank, (char *)argv[1]);
	if(strcmp((char *)argv[2], i)==0){
	insert(rank, 10);
	imprimir(rank, 10);}
	else if(strcmp((char *)argv[2], s)==0){
	selection(rank, 10);
	imprimir(rank, 10);}
	return 0;
}
